"""Measure a document, place named cells, route links and resolve paint."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict, fields, is_dataclass, replace
from collections.abc import Mapping
from pathlib import Path
from types import MappingProxyType
import hashlib
import json
from itertools import accumulate
import math
import re
import time

from ..core import Affine, Diagram, DiagramError, Envelope, Rect, resolve
from ..draw.coords import plot_area
from ..plot import Panel, PolarPanel
from ..figure import Figure, apply_theme
from ..links import link, route_all
from ..diagnostics import lint, format_report
from ..render.paint import resolve_paint
from ..themes import Theme, theme as get_theme
from .spec import BuildSpec, ComponentSpec, PlotSpec, fingerprint, length, themed
from .data import Dataset


class LayoutError(DiagramError):
    """A document cannot satisfy its declared physical layout constraints."""


@dataclass(frozen=True)
class Cell:
    name: str
    item: object
    row: int
    column: int
    rowspan: int = 1
    colspan: int = 1
    min_width: float = 20
    min_height: float = 15
    align: str = 'center'


class BuildContext:
    def __init__(self, theme, cache, preset=None):
        self.theme, self.cache = theme, cache
        self.preset = preset
        self.active = []
        self.hits = self.misses = 0

    def build(self, item, width=None, height=None):
        if isinstance(item, Diagram):
            return item
        if not isinstance(item, BuildSpec):
            # Live legacy Panels are accepted at their authored dimensions.
            if hasattr(item, 'build'):
                result = item.build()
                if isinstance(result, Diagram):
                    return result
            raise TypeError('document cells need a Diagram, Panel, PlotSpec or ComponentSpec')
        if id(item) in self.active:
            raise DiagramError('cyclic document dependency')
        # Fixed factories never receive cell dimensions. Reuse their result
        # across measurement passes and page resizes.
        if isinstance(item, ComponentSpec) and not item.responsive:
            width = height = None
        key = (id(item), repr(fingerprint(item)), width, height, repr(self.theme), repr(self.preset))
        if key in self.cache:
            self.hits += 1
            return self.cache[key]
        self.active.append(id(item))
        try:
            with themed(self.theme):
                node = item.render(self, width, height)
        finally:
            self.active.pop()
        if not isinstance(node, Diagram) or node.bbox is None:
            raise DiagramError('document component has no measurable drawing')
        self.misses += 1
        self.cache[key] = node
        # Bound retained intermediate layouts in a long-running preview.
        while len(self.cache) > 512:
            del self.cache[next(iter(self.cache))]
        return node


def _tracks(count, weights, constraints, available, gap, axis):
    """Solve contiguous span minima, then fit weighted tracks to the page.

    Longest paths between prefix sums give an exact feasibility bound. Dykstra
    projections find the closest feasible allocation to the requested weights,
    including overlapping spans whose minimum widths share the middle track.
    """
    spans={}
    for start,span,required,_ in constraints:
        spans[start,span]=max(spans.get((start,span),0),required-gap*(span-1))
    prefix=[0.]*(count+1)
    ending = {}
    for (start,span),required in spans.items():
        ending.setdefault(start+span,[]).append((start,required))
    for end in range(1,count+1):
        prefix[end]=max([prefix[end-1]]+[prefix[start]+required
                         for start,required in ending.get(end,())])
    minimum=prefix[-1]+gap*(count-1)
    if available is not None and minimum>available+1e-6:
        raise LayoutError(f'{axis} requires at least {minimum:.2f} mm; only {available:.2f} mm is available '
                          f'for cells {", ".join(c[3] for c in constraints)}. Increase the page size or reduce cell minima.')
    total=prefix[-1] if available is None else available-gap*(count-1)
    weight_sum = sum(weights)
    tracks=[total*w/weight_sum for w in weights]
    if all(span == 1 for _, span in spans):
        floors = [max(0., spans.get((index, 1), 0.)) for index in range(count)]
        remaining = max(0., total-sum(floors))
        if remaining == 0:
            return floors
        # Projection onto a simplex with per-track lower bounds. This is
        # exact in O(n log n); ordinary grids need no iterative span solver.
        values = [target-floor for target, floor in zip(tracks, floors)]
        partial = 0.
        threshold = 0.
        for rank, value in enumerate(sorted(values, reverse=True), 1):
            partial += value
            candidate = (partial-remaining)/rank
            if value > candidate:
                threshold = candidate
        return [floor+max(0., value-threshold) for floor, value in zip(floors, values)]
    sets=[(tuple(range(count)),total,True)]
    sets.extend(((index,),0.,False) for index in range(count))
    sets.extend((tuple(range(start,start+span)),required,False) for (start,span),required in spans.items())
    corrections=[0.]*len(sets)
    for _ in range(10000):
        before=tracks[:]
        for index,(indices,required,equality) in enumerate(sets):
            correction=corrections[index]
            current=sum(tracks[j]+correction for j in indices)
            adjustment=(required-current)/len(indices)
            if not equality: adjustment=max(0.,adjustment)
            for j in indices: tracks[j]+=correction+adjustment
            corrections[index]=-adjustment
        if max(abs(a-b) for a,b in zip(before,tracks))<1e-8:
            if (abs(sum(tracks)-total)<1e-6 and min(tracks)>=-1e-6
                    and all(sum(tracks[start:start+span]) >= required-1e-6
                            for (start,span),required in spans.items())):
                return [max(0.,v) for v in tracks]
    raise LayoutError(f'{axis} constraints did not converge; simplify overlapping spans')


def _margins(node):
    area, box = plot_area(node), node.bbox
    if area is None:
        return (0.,0.,0.,0.)
    return (max(0.,area.x0-box.x0), max(0.,box.x1-area.x1),
            max(0.,area.y0-box.y0), max(0.,box.y1-area.y1))


def _sources(items):
    tables, seen = {}, set()
    def canonical(value):
        if isinstance(value,float) and not math.isfinite(value):
            return {'nonfinite_number':str(value)}
        if isinstance(value,Mapping): return {k:canonical(v) for k,v in value.items()}
        if isinstance(value,(list,tuple)): return [canonical(v) for v in value]
        return value
    def visit(value):
        if id(value) in seen:
            return
        seen.add(id(value))
        if isinstance(value, Dataset):
            payload = json.dumps(canonical(value.columns), sort_keys=True, default=str, allow_nan=False).encode()
            tables[id(value)] = dict(name=value.name, revision=value.revision, units=dict(value.units),
                                     rows=len(next(iter(value.columns.values()))),
                                     data_sha256=hashlib.sha256(payload).hexdigest(),
                                     source=asdict(value.source) if value.source else None)
        elif isinstance(value, Document):
            # Traverse retained authoring objects directly. A temporary list can
            # reuse an earlier sibling's Python ID and be skipped by `seen`.
            for cell in value._cells: visit(cell.item)
        elif isinstance(value, Mapping):
            for v in value.values(): visit(v)
        elif isinstance(value, (list,tuple)):
            for v in value: visit(v)
        elif is_dataclass(value) and not isinstance(value, (Diagram,Theme)):
            for f in fields(value): visit(getattr(value,f.name))
    visit(items)
    return list(tables.values())


@dataclass(frozen=True)
class CompiledFigure:
    """A resolved snapshot; later authoring changes cannot alter its exports."""
    _figure: Figure = field(repr=False)
    cells: Mapping
    diagnostics: tuple
    metadata: Mapping
    stats: Mapping

    @property
    def scene(self):
        """Shared compiled rendering snapshot used by every native export."""
        return self._figure._scene_override

    @property
    def root(self):
        return self._figure.build()[0]

    def build(self):
        return self._figure.build()

    def lint(self, **kwargs):
        if not kwargs: return list(self.diagnostics)
        profile=self.metadata.get('publication',{})
        defaults={k:profile[k] for k in ('min_font_pt','min_stroke_mm','min_dpi','max_font_pt','max_height_mm') if k in profile}
        return self._figure.lint(**(defaults | kwargs))

    def report(self, **kwargs):
        return format_report(self.lint(**kwargs))

    def to_svg(self, *, text=None, **kwargs):
        if text is None: text=self.metadata.get('publication',{}).get('text','embed')
        return self._figure.to_svg(text=text, **kwargs)

    def to_pdf(self, *, text=None, **kwargs):
        if text is None: text=self.metadata.get('publication',{}).get('text','embed')
        return self._figure.to_pdf(text=text, **kwargs)

    def to_png(self, *, dpi=None, **kwargs):
        if dpi is None: dpi=self.metadata.get('publication',{}).get('dpi',150)
        return self._figure.to_png(dpi=dpi, **kwargs)

    def save(self, *paths, **kwargs):
        kwargs.setdefault('text', self.metadata.get('publication',{}).get('text','embed'))
        return self._figure.save(*paths, **kwargs)

    def export(self, directory, **kwargs):
        from ..render.bundle import export_bundle
        profile=self.metadata.get('publication')
        if profile:
            kwargs.setdefault('dpi',profile['dpi'])
            kwargs.setdefault('text',profile['text'])
        return export_bundle(self, directory, **kwargs)


@dataclass(eq=False)
class Document(BuildSpec):
    """A physical page containing named, live figure definitions.

    `columns` is a count or positive track weights. Cells can span tracks.
    Plot areas resize to their cells; typography is rebuilt at its actual size.
    Existing Diagram and Panel inputs retain their authored dimensions.
    """
    width: float = 180
    height: float | None = None
    columns: object = 1
    margin: float = 4
    gap: float = 6
    row_gap: float | None = None
    theme: object = 'nature'
    publication: object = None
    preset: object = None
    share_plot_margins: bool = False
    _preset_overrides: dict = field(default_factory=dict, repr=False)
    _cells: list = field(default_factory=list, repr=False)
    _links: list = field(default_factory=list, repr=False)
    _letters: dict = field(default_factory=dict, repr=False)
    _cache: dict = field(default_factory=dict, repr=False)
    _render_previous: object = field(default=None, init=False, repr=False)
    _last: object = field(default=None, repr=False)

    def __post_init__(self):
        if type(self.share_plot_margins) is not bool: raise ValueError('share_plot_margins must be a boolean')
        self.width = length(self.width, 'document width')
        if self.height is not None: self.height = length(self.height, 'document height')
        self.margin = length(self.margin, 'margin', zero=True)
        self.gap = length(self.gap, 'gap', zero=True)
        self.row_gap = self.gap if self.row_gap is None else length(self.row_gap,'row gap',zero=True)
        self.theme = get_theme(self.theme) if isinstance(self.theme,str) else self.theme
        if self.publication is not None:
            from .publication import PublicationProfile
            if not isinstance(self.publication, PublicationProfile): raise TypeError('publication must be a PublicationProfile')
        if self.preset is not None:
            from .presets import Preset
            if not isinstance(self.preset, Preset): raise TypeError('preset must be a Preset')
        if not isinstance(self.theme, Theme): raise TypeError('document theme must be a Theme or theme name')
        if isinstance(self.columns,int) and not isinstance(self.columns,bool):
            if self.columns < 1: raise ValueError('document needs at least one column')
            self.columns = (1.,)*self.columns
        else:
            self.columns = tuple(length(v,'column weight') for v in self.columns)
            if not self.columns: raise ValueError('document needs at least one column')

    def add(self, name, item, *, row=None, column=0, rowspan=1, colspan=1,
            min_width=None, min_height=None, align='center'):
        """Place a named cell; align fixed artwork by a compass point.

        Omitted row appends below existing cells. ``align`` accepts ``center``,
        ``n``, ``s``, ``e``, ``w`` and the four corners. It positions artwork
        within its cell without scaling. Plots fill their available data
        regions and retain shared axis alignment.
        """
        if not isinstance(name,str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*',name):
            raise ValueError('cell names start with a letter and contain letters, digits, underscores or hyphens')
        if any(c.name == name for c in self._cells): raise DiagramError(f'duplicate cell {name!r}')
        if align not in ('center','n','s','e','w','nw','ne','sw','se'):
            raise ValueError('cell align must be center, n, s, e, w, nw, ne, sw or se')
        row = max((c.row+c.rowspan for c in self._cells), default=0) if row is None else row
        for value,label,minimum in [(row,'row',0),(column,'column',0),(rowspan,'rowspan',1),(colspan,'colspan',1)]:
            if not isinstance(value,int) or isinstance(value,bool) or value < minimum:
                raise ValueError(f'{label} must be an integer >= {minimum}')
        if column+colspan > len(self.columns): raise LayoutError(f'cell {name!r} extends beyond the columns')
        for other in self._cells:
            if (row < other.row+other.rowspan and other.row < row+rowspan
                    and column < other.column+other.colspan and other.column < column+colspan):
                raise LayoutError(f'cell {name!r} overlaps {other.name!r}')
        if isinstance(item,Diagram):
            default_w,default_h = item.width,item.height
        else:
            default_w,default_h = 20,15
        cell=Cell(name,item,row,column,rowspan,colspan,
                  length(default_w if min_width is None else min_width,'minimum width'),
                  length(default_h if min_height is None else min_height,'minimum height'),align)
        self._cells.append(cell)
        self._last=None
        return item

    def configure(self, **options):
        """Validate page changes together before applying them."""
        names=('width','height','columns','margin','gap','row_gap','theme','publication','share_plot_margins')
        unknown=set(options).difference(names)
        if unknown: raise TypeError(f'unknown document options: {unknown!r}')
        candidate=Document(**{name:options.get(name,getattr(self,name)) for name in names}, preset=self.preset)
        for name in names: setattr(self,name,getattr(candidate,name))
        if self.preset is not None: self._preset_overrides.update(options)
        self._last=None
        return self

    def use_preset(self, selected, *, format=None, keep_overrides=True, **options):
        """Switch presets and remeasure live content, preserving explicit page options.

        selected is a preset name or Preset value. Explicit options from the
        original preset.document() and subsequent configure() calls survive;
        keep_overrides=False resets those page choices. Content and recorded
        plot styles are always retained. Pass a customized Preset for branding.
        """
        from .presets import Preset, preset
        if isinstance(selected, str): selected = preset(selected, format=format)
        elif format is not None: raise TypeError('format belongs on preset() when passing a Preset')
        if not isinstance(selected, Preset): raise TypeError('selected must be a preset name or Preset')
        overrides = (self._preset_overrides if keep_overrides else {}) | options
        overrides.setdefault('columns', self.columns)
        candidate = selected.document(**overrides)
        for name in ('width','height','columns','margin','gap','row_gap','theme','publication','preset','share_plot_margins'):
            setattr(self, name, getattr(candidate, name))
        self._preset_overrides = candidate._preset_overrides
        self._last = None
        return self

    def replace(self, name, item):
        """Replace a cell definition while retaining its layout constraints."""
        for index, cell in enumerate(self._cells):
            if cell.name==name:
                self._cells[index]=replace(cell,item=item)
                self._last=None
                return item
        raise KeyError(name)

    def link(self, source, target, **kwargs):
        """Connect named cells, optionally `cell:anchor`, after layout."""
        self._links.append((source,target,dict(kwargs)))
        self._last=None
        return self

    def __getitem__(self, name):
        """Return a named live child for subsequent edits."""
        for cell in self._cells:
            if cell.name == name: return cell.item
        raise KeyError(name)

    def letters(self, *, start='a', **options):
        """Measure panel letters with the cells, reserving room before placement."""
        self._letters = dict(start=start, **options)
        return self

    def signature(self, trail=()):
        return ('subfigure', self.width, self.height, self.columns, self.margin,
                self.gap, self.row_gap, fingerprint(self._letters, trail),
                tuple((c.name, c.row, c.column, c.rowspan, c.colspan,
                       c.min_width, c.min_height, c.align, fingerprint(c.item, trail)) for c in self._cells),
                fingerprint(self._links, trail), self.share_plot_margins)

    def render(self, context, width=None, height=None):
        self.__post_init__()
        content, _, _, page_height, _ = self._layout(
            context, self.width if width is None else width,
            self.height if height is None else height)
        return Diagram(children=(content,), kind='subfigure', envelope_override=
                       Envelope.from_rect(Rect(0, 0, self.width if width is None else width, page_height)))

    def _layout(self, context, width, height):
        if not self._cells: raise LayoutError('cannot compile an empty document')
        theme = context.theme
        cell_indices = {c.name:index for index,c in enumerate(self._cells)}
        def decorate(node, cell):
            if not self._letters: return node
            from ..draw.annotate import letters
            options = dict(self._letters)
            if context.preset is not None:
                options.setdefault('style', context.preset.letter_style)
            start = chr(ord(options.pop('start')) + cell_indices[cell.name])
            with themed(theme):
                tagged = letters([node], start=start, **options)[0]
            for name,point in node.anchors.items(): tagged.anchor(name,node.transform.apply(point))
            return tagged
        rows=max(c.row+c.rowspan for c in self._cells)
        widths=_tracks(len(self.columns),self.columns,
                       [(c.column,c.colspan,c.min_width,c.name) for c in self._cells],
                       width-2*self.margin,self.gap,'width')
        x_prefix = tuple(accumulate(widths,initial=0.))
        # Auto-height preserves authored data-region heights plus measured furniture.
        natural_heights = {}; natural_plots = {}
        for c in self._cells:
            fixed = isinstance(c.item, Diagram) or (isinstance(c.item, ComponentSpec) and not c.item.responsive)
            if height is None or fixed:
                cell_width = x_prefix[c.column+c.colspan]-x_prefix[c.column]+self.gap*(c.colspan-1)
                natural = context.build(c.item, cell_width,
                                        c.item.height if isinstance(c.item, PlotSpec) else None)
                decorated = decorate(natural, c)
                natural_heights[c.name] = decorated.height
                if isinstance(c.item,PlotSpec):
                    area=plot_area(decorated)
                    natural_plots[c.name]=(area.height,*_margins(decorated)[2:])
        if self.share_plot_margins and height is None:
            # The largest top and bottom labels may belong to different
            # plots. Sum their separate maxima so neither consumes authored
            # data height merely because its peer has different furniture.
            tallest=sum(max((v[n] for v in natural_plots.values()),default=0.) for n in range(3))
            for name in natural_plots: natural_heights[name]=tallest
        heights=_tracks(rows,(1.,)*rows,
                        [(c.row,c.rowspan,max(c.min_height, natural_heights.get(c.name,0)),c.name)
                         for c in self._cells],
                        None if height is None else height-2*self.margin,self.row_gap,'height')
        def cell_boxes(track_heights):
            y_prefix = tuple(accumulate(track_heights,initial=0.))
            return {c.name:Rect(self.margin+x_prefix[c.column]+self.gap*c.column,
                               self.margin+y_prefix[c.row]+self.row_gap*c.row,
                               self.margin+x_prefix[c.column+c.colspan]+self.gap*(c.column+c.colspan-1),
                               self.margin+y_prefix[c.row+c.rowspan]+self.row_gap*(c.row+c.rowspan-1))
                    for c in self._cells}
        boxes=cell_boxes(heights)
        margins={c.name:(0.,0.,0.,0.) for c in self._cells}
        nodes={}
        # Tick selection depends on available width, so measure to a stable fit.
        for iteration in range(24):
            for c in self._cells:
                box=boxes[c.name];left,right,top,bottom=margins[c.name]
                if isinstance(c.item,PlotSpec):
                    pw,ph=box.width-left-right,box.height-top-bottom
                    if pw < 5 or ph < 5:
                        raise LayoutError(f'cell {c.name!r} leaves only {pw:.2f} × {ph:.2f} mm for data after labels. Increase its size.')
                    nodes[c.name]=context.build(c.item,round(pw,6),round(ph,6))
                else:
                    pw,ph=box.width-left-right,box.height-top-bottom
                    if pw <= 0 or ph <= 0: raise LayoutError(f'cell {c.name!r} has no space after panel letters')
                    nodes[c.name]=context.build(c.item,pw,ph)
            undecorated={name:node.bbox for name,node in nodes.items()}
            nodes={c.name:decorate(nodes[c.name], c) for c in self._cells}
            measured={c.name:_margins(nodes[c.name]) for c in self._cells}
            if self._letters:
                for c in self._cells:
                    if isinstance(c.item,PlotSpec): continue
                    a,b=undecorated[c.name],nodes[c.name].bbox
                    measured[c.name]=tuple(max(0.,v,old) for v,old in zip(
                        (a.x0-b.x0,b.x1-a.x1,a.y0-b.y0,b.y1-a.y1),margins[c.name]))
            # Share plot margins among unspanned cells in each column/row.
            columns, row_groups = {}, {}
            for c in self._cells:
                if not isinstance(c.item,PlotSpec): continue
                left,right,top,bottom = measured[c.name]
                a,b = columns.get((c.column,c.colspan),(0.,0.))
                columns[c.column,c.colspan] = max(a,left),max(b,right)
                a,b = row_groups.get((c.row,c.rowspan),(0.,0.))
                row_groups[c.row,c.rowspan] = max(a,top),max(b,bottom)
            shared=tuple(max((measured[c.name][n] for c in self._cells if isinstance(c.item,PlotSpec)),default=0.)
                         for n in range(4)) if self.share_plot_margins else None
            for c in self._cells:
                if not isinstance(c.item,PlotSpec): continue
                m = shared if shared is not None else (*columns[c.column,c.colspan], *row_groups[c.row,c.rowspan])
                # Monotonic margins prevent tick-thinning oscillations.
                measured[c.name]=tuple(max(a,b) for a,b in zip(m,margins[c.name]))
            if height is None and natural_plots:
                # Wrapping furniture must grow automatic tracks, regardless
                # of whether margins are shared across the whole document.
                if self.share_plot_margins:
                    required = {name:(max(v[0] for v in natural_plots.values())+
                                max(measured[n][2] for n in natural_plots)+
                                max(measured[n][3] for n in natural_plots)) for name in natural_plots}
                else:
                    required = {name:values[0]+measured[name][2]+measured[name][3]
                                for name,values in natural_plots.items()}
                if any(natural_heights[name]<value-1e-6 for name,value in required.items()):
                    for name,value in required.items(): natural_heights[name]=max(natural_heights[name],value)
                    heights=_tracks(rows,(1.,)*rows,
                                    [(c.row,c.rowspan,max(c.min_height,natural_heights.get(c.name,0)),c.name)
                                     for c in self._cells],None,self.row_gap,'height')
                    boxes=cell_boxes(heights);margins=measured
                    continue
            if all(max(abs(a-b) for a,b in zip(measured[n],margins[n]))<.005 for n in margins): break
            margins=measured
        else:
            raise LayoutError('plot furniture did not settle after 24 measurement passes')
        placed=[];handles={}
        for c in self._cells:
            node,box=nodes[c.name].copy(),boxes[c.name]
            actual=node.bbox
            if actual.width > box.width+.02 or actual.height > box.height+.02:
                raise LayoutError(f'cell {c.name!r} contains {actual.width:.2f} × {actual.height:.2f} mm '
                                  f'but has {box.width:.2f} × {box.height:.2f} mm. Increase its cell size.')
            if isinstance(c.item,PlotSpec):
                area=plot_area(node);left,_,top,_=margins[c.name]
                dx,dy=box.x0+left-area.x0,box.y0+top-area.y0
            else:
                dx,dy=box.center.x-actual.center.x,box.center.y-actual.center.y
                if c.align in ('w','nw','sw'): dx=box.x0-actual.x0
                elif c.align in ('e','ne','se'): dx=box.x1-actual.x1
                if c.align in ('n','nw','ne'): dy=box.y0-actual.y0
                elif c.align in ('s','sw','se'): dy=box.y1-actual.y1
            handles[c.name]=node
            # Always wrap: at zero offset translated() returns the original
            # node, whose semantic kind (e.g. abutting artwork) must survive.
            placed.append(Diagram(children=(node,),transform=Affine.translation(dx,dy),
                                  kind='document-cell',name=c.name).carry_notes(node))
        with themed(theme):
            content=Diagram(children=tuple(placed),kind='document-content')
            if self._links:
                def endpoint(value):
                    if not isinstance(value,str): raise TypeError('document link endpoints must be cell or cell:anchor strings')
                    name,sep,anchor=value.partition(':')
                    if name not in handles: raise DiagramError(f'unknown link cell {name!r}')
                    return handles[name].at(anchor) if sep else handles[name]
                # Figure.link supplies theme-aware labels, plates and arrow defaults.
                builder=Figure(theme=theme)
                for a,b,kw in self._links: builder.link(endpoint(a),endpoint(b),**kw)
                connectors=route_all(builder._links,resolve(content))
                content=Diagram(children=(content,connectors),kind='document-content')
            page_height=height if height is not None else 2*self.margin+sum(heights)+self.row_gap*(rows-1)
        return content, boxes, handles, page_height, iteration+1

    def compile(self):
        """Measure dependencies and return a cached CompiledFigure snapshot."""
        started=time.perf_counter()
        # Revalidate public page dimensions after direct edits.
        self.__post_init__()
        width=length(self.width,'document width')
        height=None if self.height is None else length(self.height,'document height')
        theme=get_theme(self.theme) if isinstance(self.theme,str) else self.theme
        if not self._cells: raise LayoutError('cannot compile an empty document')
        context=BuildContext(theme,self._cache,self.preset)
        signatures=tuple((c.name,c.row,c.column,c.rowspan,c.colspan,c.min_width,c.min_height,c.align,
                          fingerprint(c.item) if isinstance(c.item,(BuildSpec,Diagram,Panel,PolarPanel)) else id(context.build(c.item)))
                         for c in self._cells)
        key=repr((width,height,self.columns,self.margin,self.gap,self.row_gap,theme,signatures,self._links,self._letters,self.publication,self.preset,self.share_plot_margins))
        if self._last is not None and self._last[0]==key and self._last[1].scene.sources_current():
            return self._last[1]
        dependency_seconds=time.perf_counter()-started
        content, boxes, handles, page_height, passes = self._layout(context, width, height)
        layout_seconds=time.perf_counter()-started
        with themed(theme):
            root=Diagram(children=(content,),kind='page',envelope_override=Envelope.from_rect(Rect(0,0,width,page_height)))
            program=resolve_paint(apply_theme(root,theme),stable_ids=True)
            placements=resolve(program.root)
            paint_finished=time.perf_counter()
            from ..render.scene import compile_scene
            scene = compile_scene(program.root, previous=self._render_previous)
            scene_finished=time.perf_counter()
            diagnostics=tuple(lint(program.root,page=program.root.bbox,placements=placements,page_fill=theme.paper,
                                   **({} if self.publication is None else self.publication.checks)))
        diagnostics_seconds=time.perf_counter()-scene_finished
        figure=Figure(width=width,height=page_height,margin=0,theme=theme)
        figure._built=(program.root,placements)
        figure._scene_override=scene
        from ..core.prims import TextPrim
        font_paths=set()
        for placement in placements.values():
            prim=placement.diagram.prim
            if isinstance(prim,TextPrim):
                if prim.font_path: font_paths.add(prim.font_path)
                for line in prim.lines:
                    for run in line.runs:
                        if run.font_path: font_paths.add(run.font_path)
        fonts=[dict(file=Path(path).name,sha256=hashlib.sha256(Path(path).read_bytes()).hexdigest())
               for path in sorted(font_paths)]
        from ..assets.provenance import credits
        from .. import __version__
        alignment = {c.name:c.align for c in self._cells}
        metadata=dict(assets=[asdict(p) for p in credits(program.root)],schema_version=2,inklet_version=__version__,width_mm=width,height_mm=page_height,fonts=fonts,
                      cells={name:dict(x=box.x0,y=box.y0,width=box.width,height=box.height,
                                       node_id=program.ids[handles[name].id],align=alignment[name]) for name,box in boxes.items()},
                      datasets=_sources([c.item for c in self._cells]))
        from ..render.resources import rendering_manifest
        metadata['rendering'] = rendering_manifest(program.root)
        if self.publication is not None: metadata['publication']=asdict(self.publication)
        if self.preset is not None:
            metadata['preset'] = self.preset.as_dict()
            metadata['preset']['page_overrides'] = sorted(self._preset_overrides)
        finished=time.perf_counter()
        stats=dict(build_seconds=finished-started,layout_seconds=layout_seconds,
                   paint_seconds=paint_finished-started-layout_seconds,diagnostics_seconds=diagnostics_seconds,
                   dependency_seconds=dependency_seconds,
                   fitting_seconds=layout_seconds-dependency_seconds,
                   metadata_seconds=finished-scene_finished-diagnostics_seconds,
                   render_scene_seconds=scene_finished-paint_finished,
                   render_scene=dict(scene.stats),
                   cache_hits=context.hits,
                   builds=context.misses,layout_passes=passes,node_count=program.node_count)
        result=CompiledFigure(figure,MappingProxyType(boxes),diagnostics,
                              MappingProxyType(metadata),MappingProxyType(stats))
        self._last=(key,result)
        self._render_previous=scene
        return result

    def export(self,directory,**kwargs):
        return self.compile().export(directory,**kwargs)

    def save(self,*paths,**kwargs):
        return self.compile().save(*paths,**kwargs)


def document(*, width=180, height=None, columns=1, margin=4, gap=6, row_gap=None, theme='nature', publication=None, share_plot_margins=False):
    """Create a live document; optionally share plot furniture across the grid.

    Shared margins reserve the largest labels/letters on every plot and use
    the tallest data region plus shared furniture for automatic row heights. Equal tracks and
    unspanned plot cells then have equal data areas. Fixed artwork is unchanged;
    unequal track weights, spans or larger cell minima can still vary areas.
    """
    return Document(width,height,columns,margin,gap,row_gap,theme,publication,share_plot_margins=share_plot_margins)


def subfigure(*, width=180, height=None, columns=1, margin=0, gap=6, row_gap=None, share_plot_margins=False):
    """Create a nested grid. Children inherit the enclosing document theme.

    Use the same add/replace/link/letters API as Document. Width and height are
    defaults; a containing cell supplies the available physical dimensions.
    Nested layout shares measurement caches and runs paint and diagnostics only
    once, when the complete document is compiled.
    """
    return Document(width=width, height=height, columns=columns, margin=margin,
                    gap=gap, row_gap=row_gap,share_plot_margins=share_plot_margins)
